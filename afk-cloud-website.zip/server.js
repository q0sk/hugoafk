const express = require("express");
const session = require("express-session");
const bcrypt = require("bcrypt");
const mineflayer = require("mineflayer");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const SECRET = process.env.SESSION_SECRET || "change-this-secret";

app.use(express.json());
app.use(express.static("public"));
app.use(session({
  secret: SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: false, maxAge: 7*24*60*60*1000 }
}));

const DATA = "data.json";
let users = fs.existsSync(DATA) ? JSON.parse(fs.readFileSync(DATA)) : [];
let bot = null;
let botState = { status: "offline", logs: [] };

function save(){ fs.writeFileSync(DATA, JSON.stringify(users, null, 2)); }
function auth(req,res,next){ if(!req.session.userId) return res.status(401).json({error:"Nicht eingeloggt"}); next(); }
function log(x){ botState.logs.push(`[${new Date().toLocaleTimeString("de-DE")}] ${x}`); botState.logs = botState.logs.slice(-120); }

app.post("/api/register", async (req,res)=>{
  const username=String(req.body.username||"").trim();
  const password=String(req.body.password||"");
  if(username.length<3 || password.length<8) return res.status(400).json({error:"Benutzername oder Passwort ungültig"});
  if(users.some(u=>u.username.toLowerCase()===username.toLowerCase())) return res.status(409).json({error:"Benutzername bereits vorhanden"});
  const passwordHash=await bcrypt.hash(password,12);
  users.push({id:Date.now().toString(),username,passwordHash,serverHost:"",serverPort:25565});
  save(); req.session.userId=users.at(-1).id; res.json({ok:true});
});
app.post("/api/login", async (req,res)=>{
  const u=users.find(x=>x.username===String(req.body.username||""));
  if(!u || !(await bcrypt.compare(String(req.body.password||""),u.passwordHash))) return res.status(401).json({error:"Login fehlgeschlagen"});
  req.session.userId=u.id; res.json({ok:true});
});
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));
app.get("/api/me",auth,(req,res)=>{
  const u=users.find(x=>x.id===req.session.userId);
  res.json({username:u.username,serverHost:u.serverHost,serverPort:u.serverPort});
});
app.post("/api/settings",auth,(req,res)=>{
  const host=String(req.body.serverHost||"").trim();
  const port=Number(req.body.serverPort||25565);
  if(!host) return res.status(400).json({error:"Server-Adresse fehlt"});
  if(!Number.isInteger(port)||port<1||port>65535) return res.status(400).json({error:"Ungültiger Port"});
  const u=users.find(x=>x.id===req.session.userId); u.serverHost=host; u.serverPort=port; save();
  res.json({ok:true});
});
app.get("/api/bot/status",auth,(req,res)=>res.json(botState));

app.post("/api/bot/start",auth,(req,res)=>{
  if(bot) return res.status(400).json({error:"Bot läuft bereits"});
  const u=users.find(x=>x.id===req.session.userId);
  if(!u.serverHost) return res.status(400).json({error:"Bitte zuerst Server-Adresse speichern"});
  botState={status:"login",logs:[]};
  log(`Verbinde mit ${u.serverHost}:${u.serverPort} ...`);
  try {
    bot=mineflayer.createBot({
      host:u.serverHost,
      port:u.serverPort,
      username:"afk-web-bot",
      auth:"microsoft",
      version:false
    });
    bot.once("spawn",()=>{
      botState.status="online";
      log("Bot ist online.");
      setInterval(()=>{
        if(bot && bot.entity){
          bot.setControlState("jump",true);
          setTimeout(()=>bot && bot.setControlState("jump",false),250);
        }
      }, 20000);
    });
    bot.on("message",m=>log(m.toString()));
    bot.on("kicked",r=>{ log("Gekickt: "+r); botState.status="offline"; bot=null; });
    bot.on("error",e=>log("Fehler: "+e.message));
    bot.on("end",()=>{ log("Verbindung beendet."); botState.status="offline"; bot=null; });
  } catch(e){ bot=null; botState.status="offline"; return res.status(500).json({error:e.message}); }
  res.json({ok:true});
});
app.post("/api/bot/stop",auth,(req,res)=>{
  if(bot){ log("Bot wird gestoppt."); bot.quit("Dashboard stop"); bot=null; }
  botState.status="offline"; res.json({ok:true});
});

app.listen(PORT,()=>console.log(`AFK Web läuft auf http://localhost:${PORT}`));
