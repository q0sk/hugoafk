# AFK Cloud Control

1. Node.js 18+ installieren.
2. `npm install`
3. `.env.example` nach `.env` kopieren und einen langen SESSION_SECRET setzen.
4. `npm start`
5. `http://localhost:3000` öffnen.

Für Betrieb bei ausgeschaltetem eigenen PC muss die Anwendung auf einem dauerhaft
laufenden VPS/Server gehostet werden. Nutze den Bot nur auf Servern, die Bots/AFK
erlauben.

Beim ersten Microsoft-Login kann Mineflayer einen Gerätecode/Link im Terminal
ausgeben. Der Minecraft-Account wird nicht als Passwort im Dashboard gespeichert.
